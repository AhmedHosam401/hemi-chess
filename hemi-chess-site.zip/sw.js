/* Hemi Chess service worker: lets the game open from the home screen and work offline.
   Only same-origin files are handled; Firebase, fonts and everything else go straight to the network. */
var V = 'hemi-9736326952';
var SHELL = ['./', 'index.html', 'manifest.webmanifest', 'logo-192.png', 'logo-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png', 'NOTICE.txt', 'LOGO-NOTE.txt'];
['cburnett', 'mpchess'].forEach(function (set) { ['w', 'b'].forEach(function (c) { 'KQRBNP'.split('').forEach(function (p) { SHELL.push(set + '/' + c + p + '.svg'); }); }); });

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) {
    return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () { }); }));
  }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== V && k.indexOf('hemi-') === 0; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var r = e.request;
  if (r.method !== 'GET') return;
  var u = new URL(r.url);
  if (u.origin !== self.location.origin) return;
  if (r.mode === 'navigate') { // page: network first (so updates arrive), cached copy when offline
    e.respondWith(fetch(r, { cache: 'no-cache' }).then(function (res) {
      if (res && res.ok) { var cp = res.clone(); caches.open(V).then(function (c) { c.put('index.html', cp); }); }
      return res;
    }).catch(function () {
      return caches.match('index.html').then(function (h) { return h || caches.match('./'); });
    }));
    return;
  }
  e.respondWith(caches.match(r).then(function (hit) { // files: cache first, refreshed in the background
    var net = fetch(r).then(function (res) {
      if (res && res.ok) { var cp = res.clone(); caches.open(V).then(function (c) { c.put(r, cp); }); }
      return res;
    }).catch(function () { return hit; });
    return hit || net;
  }));
});
